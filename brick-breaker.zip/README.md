# brick-breaker

# development process
I used an agile method called "	extreme programming for one" and broke game features into stories and tasks.
I designed an Uml chart to help me visualize the game structure it can be found in Assets/UmlChart.png.
http://c2.com/cgi/wiki?ExtremeProgrammingForOne
	
# game keys
left arrow key -> move the paddle to the left.
right arrow key -> move the paddle to the right.
space -> begin the game.

# game options
You can enable and disable sound.

# About
You can reset your options settings and find more about this project.

# not finished feature
It was planned to add extra feature like extra levels and power ups, unfortunately I didn't have time but my code is very flexible and they could be implemented very easily.

# Problems
Memory info doesn't display on html5 because in javascript you can't get memory info, to check for memory use the flash version.

# notes
Attention to the fact html5 must be running on a web server due to cross origin request problems

The both versions of the game(html5 and flash) can be found in the Export folder.